### Deploy the enviroment
Type ```pip install -r requirements.txt``` in terminal
### How to Run
Type ```python3 main.py -i <file_path> -s <file_path> -o <file_path>``` in terminal
Substitute ```<filepath>``` with your own file path 
eg. python3 main.py -i data.docx -s data.xlsx -o modified_data.xlsx